const trips = require('../data/trips.json');

const index = (req, res) => {
  res.render('index', { title: 'Travlr Getaways', activePage: 'home' });
};

const travel = (req, res) => {
  res.render('travel', { title: 'Travel', activePage: 'travel', trips });
};

const rooms = (req, res) => {
  res.render('rooms', { title: 'Rooms', activePage: 'rooms' });
};

const meals = (req, res) => {
  res.render('meals', { title: 'Meals', activePage: 'meals' });
};

const news = (req, res) => {
  res.render('news', { title: 'News', activePage: 'news' });
};

const about = (req, res) => {
  res.render('about', { title: 'About', activePage: 'about' });
};

const contact = (req, res) => {
  res.render('contact', { title: 'Contact', activePage: 'contact' });
};

module.exports = { index, travel, rooms, meals, news, about, contact };