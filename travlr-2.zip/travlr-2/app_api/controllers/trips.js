const Trip = require('../models/trips');

// GET /api/trips -> return trips as JSON
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find().sort({ createdAt: -1 }).lean();
    return res.status(200).json(trips);
  } catch (err) {
    return res.status(500).json({
      message: 'Error retrieving trips',
      error: err.message
    });
  }
};

module.exports = { tripsList };
