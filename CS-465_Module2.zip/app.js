const express = require('express');
const path = require('path');

const app = express();

console.log('APP STARTED FROM:', __filename);

// Log every request + final response headers
app.use((req, res, next) => {
  console.log('REQ:', req.method, req.url);
  res.on('finish', () => {
    console.log(
      'RES:',
      req.method,
      req.url,
      'status=',
      res.statusCode,
      'len=',
      res.getHeader('Content-Length'),
      'type=',
      res.getHeader('Content-Type')
    );
  });
  next();
});

// Handlebars setup
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Routes FIRST
const routes = require('./app_server/routes/index');
console.log('ROUTES LOADED FROM:', require.resolve('./app_server/routes/index'));
app.use('/', routes);

// Static AFTER routes
app.use(express.static(path.join(__dirname, 'public')));

// 404 last
app.use((req, res) => {
  res.status(404).type('text/plain').send('404 – Page Not Found');
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

module.exports = app;