const index = (req, res) => {
  res.render('index', {
    title: 'Home'
  });
};

const travel = (req, res) => {
  res.render('travel', {
    title: 'Travel',
    message: 'Explore destinations and plan your next getaway with Travlr Getaways.'
  });
};

module.exports = {
  index,
  travel
};