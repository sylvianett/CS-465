const express = require('express');
const router = express.Router();

const ctrlTrips = require('../controllers/trips');
const ctrlAuth = require('../controllers/auth');
const { requireAuth } = require('../middleware/auth');

// AUTH
router.post('/register', ctrlAuth.register);
router.post('/login', ctrlAuth.login);
router.get('/users', requireAuth, ctrlAuth.listUsers);

// TRIPS (public read)
router.get('/trips', ctrlTrips.tripsList);
router.get('/trips/:tripid', ctrlTrips.tripsFindByCode);

// TRIPS (admin write)
router.post('/trips', requireAuth, ctrlTrips.tripsAddTrip);
router.put('/trips/:tripid', requireAuth, ctrlTrips.tripsUpdateTrip);
router.delete('/trips/:tripid', requireAuth, ctrlTrips.tripsDeleteTrip);

module.exports = router;
