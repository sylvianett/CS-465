const Trip = require('../models/trips');

// helper: basic ObjectId check
const isValidObjectId = (id) => /^[0-9a-fA-F]{24}$/.test(id);

// GET /api/trips -> return trips as JSON
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find().sort({ createdAt: -1 }).lean();
    return res.status(200).json(trips);
  } catch (err) {
    return res.status(500).json({
      message: 'Error retrieving trips',
      error: err.message
    });
  }
};

// GET /api/trips/:tripid -> return a single trip as JSON
const tripsFindById = async (req, res) => {
  const { tripid } = req.params;

  if (!isValidObjectId(tripid)) {
    return res.status(400).json({ message: 'Invalid trip id' });
  }

  try {
    const trip = await Trip.findById(tripid).lean();

    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }

    return res.status(200).json(trip);
  } catch (err) {
    return res.status(500).json({
      message: 'Error retrieving trip',
      error: err.message
    });
  }
};

// POST /api/trips -> create
const tripsAddTrip = async (req, res) => {
  try {
    const newTrip = await Trip.create({
      name: req.body.name,
      description: req.body.description,
      image: req.body.image,
      pricePerNight: req.body.pricePerNight,
      rating: req.body.rating
    });

    return res.status(201).json(newTrip);
  } catch (err) {
    return res.status(400).json({
      message: 'Error creating trip',
      error: err.message
    });
  }
};

// PUT /api/trips/:tripid -> update
const tripsUpdateTrip = async (req, res) => {
  const { tripid } = req.params;

  if (!isValidObjectId(tripid)) {
    return res.status(400).json({ message: 'Invalid trip id' });
  }

  try {
    const updated = await Trip.findByIdAndUpdate(
      tripid,
      {
        name: req.body.name,
        description: req.body.description,
        image: req.body.image,
        pricePerNight: req.body.pricePerNight,
        rating: req.body.rating
      },
      { new: true, runValidators: true }
    ).lean();

    if (!updated) {
      return res.status(404).json({ message: 'Trip not found' });
    }

    return res.status(200).json(updated);
  } catch (err) {
    return res.status(400).json({
      message: 'Error updating trip',
      error: err.message
    });
  }
};

// DELETE /api/trips/:tripid -> delete
const tripsDeleteTrip = async (req, res) => {
  const { tripid } = req.params;

  if (!isValidObjectId(tripid)) {
    return res.status(400).json({ message: 'Invalid trip id' });
  }

  try {
    const deleted = await Trip.findByIdAndDelete(tripid).lean();

    if (!deleted) {
      return res.status(404).json({ message: 'Trip not found' });
    }

    return res.status(204).send();
  } catch (err) {
    return res.status(500).json({
      message: 'Error deleting trip',
      error: err.message
    });
  }
};

module.exports = {
  tripsList,
  tripsFindById,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};