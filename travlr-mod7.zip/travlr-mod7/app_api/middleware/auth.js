const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'travlr_super_secret_change_me';

function requireAuth(req, res, next) {
  const hdr = req.headers.authorization || '';
  const [scheme, token] = hdr.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ message: 'Missing Bearer token' });
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    return next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid/expired token' });
  }
}

module.exports = { requireAuth };
