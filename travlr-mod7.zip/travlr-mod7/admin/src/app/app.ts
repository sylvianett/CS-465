import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripListComponent } from './components/trip-list/trip-list';
import { LoginComponent } from './login/login';
import { AuthService } from './services/auth';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, TripListComponent, LoginComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class AppComponent {
  constructor(public auth: AuthService) {}
}
