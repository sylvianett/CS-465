export interface Trip {
  _id?: string;
  name: string;
  description: string;
  image: string;
  pricePerNight: number;
  rating: number;
}
