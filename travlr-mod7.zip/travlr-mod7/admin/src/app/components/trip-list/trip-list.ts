import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TripDataService, Trip } from '../../services/trip-data';
import { TripCardComponent } from '../trip-card/trip-card';

@Component({
  selector: 'app-trip-list',
  standalone: true,
  imports: [CommonModule, FormsModule, TripCardComponent],
  templateUrl: './trip-list.html',
  styleUrl: './trip-list.css'
})
export class TripListComponent implements OnInit {
  trips: Trip[] = [];

  // add form model
  newTrip: Trip = {
    name: '',
    description: '',
    image: '/images/reef1.jpg',
    pricePerNight: 199,
    rating: 4.5
  };

  // edit state
  editingId: string | null = null;
  editTrip: Partial<Trip> = {};

  error = '';

  constructor(private tripService: TripDataService) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  loadTrips(): void {
    this.tripService.getTrips().subscribe({
      next: (data) => this.trips = data,
      error: () => this.error = 'Failed to load trips'
    });
  }

  startEdit(trip: Trip): void {
    this.editingId = trip._id || null;
    this.editTrip = { ...trip };
  }

  cancelEdit(): void {
    this.editingId = null;
    this.editTrip = {};
  }

  saveEdit(): void {
    if (!this.editingId) return;

    const { name, description, image, pricePerNight, rating } = this.editTrip;
    this.tripService.updateTrip(this.editingId, { name, description, image, pricePerNight, rating }).subscribe({
      next: () => { this.cancelEdit(); this.loadTrips(); },
      error: (err) => this.error = err?.error?.message || 'Update failed (are you logged in?)'
    });
  }

  deleteTrip(id?: string): void {
    if (!id) return;
    this.tripService.deleteTrip(id).subscribe({
      next: () => this.loadTrips(),
      error: (err) => this.error = err?.error?.message || 'Delete failed (are you logged in?)'
    });
  }

  addTrip(): void {
    this.tripService.addTrip(this.newTrip).subscribe({
      next: () => {
        this.newTrip = { name: '', description: '', image: '/images/reef1.jpg', pricePerNight: 199, rating: 4.5 };
        this.loadTrips();
      },
      error: (err) => this.error = err?.error?.message || 'Create failed (are you logged in?)'
    });
  }
}
