import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Trip } from '../../models/trip';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-card.html',
  styleUrl: './trip-card.css'
})
export class TripCard {
  @Input() trip!: Trip;

  // Express serves images on 3000
  apiBase = 'http://localhost:3000';
}
