const express = require('express');
const path = require('path');
const { engine } = require('express-handlebars');
const cors = require('cors');

const app = express();
app.use(cors());


// MongoDB / Mongoose connection
require('./app_api/models/db');
require('./app_api/models/trips');
require('./app_api/models/user');

console.log('APP STARTED FROM:', __filename);

// --------------------------------------------------
// MIDDLEWARE
// --------------------------------------------------

// REQUIRED for POST/PUT (Angular + Postman bodies)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Log every request + final response headers
app.use((req, res, next) => {
  console.log('REQ:', req.method, req.url);
  res.on('finish', () => {
    console.log(
      'RES:',
      req.method,
      req.url,
      'status=',
      res.statusCode,
      'len=',
      res.getHeader('Content-Length'),
      'type=',
      res.getHeader('Content-Type')
    );
  });
  next();
});

// --------------------------------------------------
// VIEW ENGINE (Handlebars)
// --------------------------------------------------

app.engine(
  'hbs',
  engine({
    extname: 'hbs',
    defaultLayout: 'main',
    layoutsDir: path.join(__dirname, 'app_server', 'views', 'layouts'),
    partialsDir: path.join(__dirname, 'app_server', 'views', 'partials'),
    helpers: {
      eq: (a, b) => a === b
    }
  })
);

app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// --------------------------------------------------
// ROUTES
// --------------------------------------------------

const routes = require('./app_server/routes/index');
const apiRoutes = require('./app_api/routes/index');

console.log('ROUTES LOADED FROM:', require.resolve('./app_server/routes/index'));

app.use('/', routes);
app.use('/api', apiRoutes);

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// --------------------------------------------------
// 404 HANDLER (must be last)
// --------------------------------------------------

app.use((req, res) => {
  res.status(404).type('text/plain').send('404 – Page Not Found');
});

// --------------------------------------------------
// START SERVER
// --------------------------------------------------

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

module.exports = app;