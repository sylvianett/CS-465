/**
 * Seed script for CS 465 Module Four.
 * Loads trips.json into MongoDB using Mongoose.
 *
 * Run:
 *   node seed.js
 *
 * Optional:
 *   MONGODB_URI="your uri" node seed.js
 */
require('./app_api/models/db');
const Trip = require('./app_api/models/trips');
const fs = require('fs');
const path = require('path');

async function seed() {
  const tripsPath = path.join(__dirname, 'trips.json');
  const raw = fs.readFileSync(tripsPath, 'utf-8');
  const trips = JSON.parse(raw);

  // Clear and insert
  await Trip.deleteMany({});
  const inserted = await Trip.insertMany(trips, { ordered: true });

  console.log(`✅ Seed complete. Inserted ${inserted.length} trips.`);
  process.exit(0);
}

seed().catch((err) => {
  console.error('❌ Seed failed:', err.message);
  process.exit(1);
});
