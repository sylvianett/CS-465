const Trip = require('../models/trips');

// GET /api/trips -> return trips as JSON
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find().sort({ createdAt: -1 }).lean();
    return res.status(200).json(trips);
  } catch (err) {
    return res.status(500).json({
      message: 'Error retrieving trips',
      error: err.message
    });
  }
};

// GET /api/trips/:tripid -> return a single trip as JSON
const tripsFindById = async (req, res) => {
  const { tripid } = req.params;

  // Basic validation so invalid ObjectIds return 400 instead of crashing
  if (!tripid || !tripid.match(/^[0-9a-fA-F]{24}$/)) {
    return res.status(400).json({ message: 'Invalid trip id' });
  }

  try {
    const trip = await Trip.findById(tripid).lean();

    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }

    return res.status(200).json(trip);
  } catch (err) {
    return res.status(500).json({
      message: 'Error retrieving trip',
      error: err.message
    });
  }
};

module.exports = { tripsList, tripsFindById };
