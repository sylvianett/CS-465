const express = require('express');
const router = express.Router();

const tripsController = require('../controllers/trips');

// GET /api/trips  -> list all trips
router.get('/trips', tripsController.tripsList);

// GET /api/trips/:tripid -> get one trip by Mongo _id
router.get('/trips/:tripid', tripsController.tripsFindById);

module.exports = router;
