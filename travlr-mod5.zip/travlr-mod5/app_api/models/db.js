const mongoose = require('mongoose');

const defaultUri = 'mongodb://127.0.0.1:27017/travlr';
const mongoUri = process.env.MONGODB_URI || defaultUri;

// Connect once on app start
mongoose.connect(mongoUri)
  .then(() => console.log('MongoDB connected:', mongoUri))
  .catch((err) => console.error('MongoDB connection error:', err.message));

// Connection events (useful for debugging / rubric "error-handling logic")
mongoose.connection.on('connected', () => console.log('Mongoose connected'));
mongoose.connection.on('error', (err) => console.error('Mongoose error:', err.message));
mongoose.connection.on('disconnected', () => console.log('Mongoose disconnected'));

// Clean shutdown
process.on('SIGINT', async () => {
  try {
    await mongoose.connection.close();
    console.log('Mongoose disconnected through app termination');
    process.exit(0);
  } catch (err) {
    console.error('Error closing mongoose connection:', err.message);
    process.exit(1);
  }
});
