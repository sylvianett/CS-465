const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Trip name is required'],
      trim: true,
      minlength: [3, 'Trip name must be at least 3 characters'],
      maxlength: [80, 'Trip name must be 80 characters or less']
    },
    description: {
      type: String,
      required: [true, 'Trip description is required'],
      trim: true,
      minlength: [10, 'Trip description must be at least 10 characters']
    },
    // Optional fields (safe for future modules)
    image: { type: String, trim: true, default: '' },
    pricePerNight: { type: Number, min: 0, default: 0 },
    rating: { type: Number, min: 0, max: 5, default: 0 }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Trip', tripSchema);
