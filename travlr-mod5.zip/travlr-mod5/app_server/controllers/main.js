// Front-end controllers
// In Module 5, the UI should request trip data from the REST API
// (Separation of Concerns) rather than reading the JSON or DB directly.

const http = require('http');

const apiOptions = {
  server: 'http://localhost:3000',
};

// Simple helper to fetch JSON from our API without adding extra dependencies
const getJSON = (path, callback) => {
  const request = http.get(`${apiOptions.server}${path}`, (response) => {
    let data = '';
    response.on('data', (chunk) => {
      data += chunk;
    });
    response.on('end', () => {
      let parsed;
      try {
        parsed = JSON.parse(data);
      } catch (e) {
        return callback(response.statusCode, null);
      }
      callback(response.statusCode, parsed);
    });
  });

  request.on('error', () => {
    callback(500, null);
  });
};

const index = (req, res) => {
  res.render('index', { title: 'Travlr Getaways', activePage: 'home' });
};

const renderTravel = (req, res, trips, errorMessage) => {
  res.render('travel', {
    title: 'Travel',
    activePage: 'travel',
    trips,
    errorMessage,
  });
};

const travel = (req, res) => {
  getJSON('/api/trips', (status, data) => {
    if (status === 200 && Array.isArray(data)) {
      renderTravel(req, res, data);
    } else {
      renderTravel(req, res, [], 'Unable to load trip data from the API.');
    }
  });
};

const rooms = (req, res) => {
  res.render('rooms', { title: 'Rooms', activePage: 'rooms' });
};

const meals = (req, res) => {
  res.render('meals', { title: 'Meals', activePage: 'meals' });
};

const news = (req, res) => {
  res.render('news', { title: 'News', activePage: 'news' });
};

const about = (req, res) => {
  res.render('about', { title: 'About', activePage: 'about' });
};

const contact = (req, res) => {
  res.render('contact', { title: 'Contact', activePage: 'contact' });
};

module.exports = { index, travel, rooms, meals, news, about, contact };